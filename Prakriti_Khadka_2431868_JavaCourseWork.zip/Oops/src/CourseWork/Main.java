package CourseWork;

import java.util.LinkedList;

//Main class for setting up and displaying the GUI application.

public class Main {

    private LinkedList<Account> accounts;
    private String file;
    private ReadAccounts readAccounts;
    private GUI gui;

    public Main() {
        file = "resources/Accounts.csv"; 
        readAccounts = new ReadAccounts(file);

// Initialize the accounts list with Account objects
        accounts = createAccountsFromData();

// Initialize the GUI with the accounts list
        gui = new GUI(accounts);
    }

//Converts the data read from the file into Account objects and return a LinkedList of Account objects.
    
    private LinkedList<Account> createAccountsFromData() {
        LinkedList<Account> accountList = new LinkedList<>();
        LinkedList<String> firstNames = readAccounts.getFirstNames();
        LinkedList<String> lastNames = readAccounts.getLastNames();
        LinkedList<Integer> accountNumbers = readAccounts.getAccounts();
        LinkedList<Integer> balances = readAccounts.getBalances();

// Ensure all lists are of the same size
        
        if (firstNames.size() == lastNames.size() &&
            lastNames.size() == accountNumbers.size() &&
            accountNumbers.size() == balances.size()) {

            for (int i = 0; i < firstNames.size(); i++) {
                String firstName = firstNames.get(i);
                String lastName = lastNames.get(i);
                int accountNumber = accountNumbers.get(i);
                int balance = balances.get(i);

                Account account = new Account(firstName, lastName, accountNumber, balance);
                accountList.add(account);
            }
        } else {
            System.err.println("Mismatch in data sizes. Unable to create accounts.");
        }

        return accountList;
    }
    

//    Sets up and displays the GUI.
    
    public void setGUIVisible() {
        gui.setVisible(true);
    }

 // Set the layout manager if needed, or customize the layout
    
    public void setupLayout() {
        gui.setLayout(null); 
    }


//Handles closing of the GUI application.
    
    public void closeGUI() {
        gui.dispose();
    }


//Main method to run the application.
 
    public static void main(String[] args) {
        Main mainApp = new Main();
        mainApp.setupLayout();
        mainApp.setGUIVisible();
    }
}



