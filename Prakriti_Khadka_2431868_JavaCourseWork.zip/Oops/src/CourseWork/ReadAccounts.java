package CourseWork;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

//Reads account data from a CSV file and stores it in LinkedLists.

public class ReadAccounts {

    private LinkedList<String> firstNames;
    private LinkedList<String> lastNames;
    private LinkedList<Integer> accountNumbers;
    private LinkedList<Integer> balances;

//Constructor that initializes the lists and reads the file.
    
    public ReadAccounts(String filePath) {
        firstNames = new LinkedList<>();
        lastNames = new LinkedList<>();
        accountNumbers = new LinkedList<>();
        balances = new LinkedList<>();
        readFile(filePath);
    }

//    Reads account data from the specified file.
    
    private void readFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 4) {
                    System.err.println("Skipping line with insufficient data: " + line);
                    continue; // This code is to skip lines with insufficient data
                }

                try {
                    String firstName = parts[0].trim();
                    String lastName = parts[1].trim();
                    int accountNumber = Integer.parseInt(parts[2].trim());
                    int balance = Integer.parseInt(parts[3].trim());

                    firstNames.add(firstName);
                    lastNames.add(lastName);
                    accountNumbers.add(accountNumber);
                    balances.add(balance);

                } catch (NumberFormatException e) {
                    System.err.println("Invalid number format in line: " + line + " - " + e.getMessage());
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading file: " + filePath + " - " + e.getMessage());
        }
    }

    public LinkedList<String> getFirstNames() {
        return firstNames;
    }

    public LinkedList<String> getLastNames() {
        return lastNames;
    }

    public LinkedList<Integer> getAccounts() {
        return accountNumbers;
    }

    public LinkedList<Integer> getBalances() {
        return balances;
    }

    public static void main(String[] args) {
        String filePath = "resources/Accounts.csv";
        ReadAccounts readAccounts = new ReadAccounts(filePath);

        
        //Just to Debug 
        
        System.out.println("Customers: " + readAccounts.getFirstNames());
        System.out.println("Surnames: " + readAccounts.getLastNames());
        System.out.println("Accounts: " + readAccounts.getAccounts());
        System.out.println("Amounts: " + readAccounts.getBalances());
    }
}





