package CourseWork;

class Transaction {
    public void transfer(Account acc1, Account acc2, int amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive.");
        }
        if (acc1.getBalance() < amount) {
            throw new IllegalArgumentException("Insufficient funds in the source account.");
        }

        acc1.withdraw(amount);
        acc2.deposit(amount);
    }
}