package CourseWork;

class Account extends Customer {
    private int balance;
    private int accountNumber;

    public Account(String firstName, String lastName, int accountNumber, double balance) {
        super(firstName, lastName); // Call the constructor of the superclass
        this.accountNumber = accountNumber;
        this.balance = (int) balance; // Convert double to int if necessary
    }

    public int getBalance() {
        return balance;
    }

    public int getAccountNum() {
        return accountNumber;
    }

    public void deposit(int amount) {
        this.balance += amount;
    }

    public void withdraw(int amount) {
        this.balance -= amount;
    }
}