package CourseWork;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.io.FileWriter;
//import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.io.PrintWriter;
//import java.io.BufferedReader;
//import java.io.FileReader;
//import java.util.ArrayList;
//import java.util.List;



public class GUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField accDep;
    private JTextField accWith;
    private JTextField acc1;
    private JTextField acc2;
    private JTextField depInp;
    private JTextField withInp;
    private JTextField transAmnt;
    private JTextArea details;
    private LinkedList<Account> accounts;

    public GUI(LinkedList<Account> accounts) {
        this.accounts = accounts;
        initialize();
    }

    private void initialize() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1116, 703);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Banking System");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblNewLabel.setBounds(426, 26, 269, 49);
        contentPane.add(lblNewLabel);

        // Add labels and text fields to the panel
        setupUIComponents();

        // Add action listeners to buttons
        setupButtonActions();
    }

    // Method to setup UI components
    private void setupUIComponents() {
        
        JLabel lblAccWithdraw = new JLabel("accWithdraw");
        lblAccWithdraw.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAccWithdraw.setBounds(10, 187, 193, 49);
            contentPane.add(lblAccWithdraw);

        JLabel lblAcctransfer = new JLabel("acc1Transfer");
        lblAcctransfer.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAcctransfer.setBounds(10, 247, 193, 49);
        contentPane.add(lblAcctransfer);

        JLabel lblAcctransfer_2 = new JLabel("acc2Transfer");
        lblAcctransfer_2.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAcctransfer_2.setBounds(10, 307, 193, 49);
        contentPane.add(lblAcctransfer_2);

        JLabel lblAcctransfer_2_1 = new JLabel("depositAmount");
        lblAcctransfer_2_1.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAcctransfer_2_1.setBounds(10, 372, 193, 49);
        contentPane.add(lblAcctransfer_2_1);

        JLabel lblAcctransfer_2_2 = new JLabel("withdrawAmount");
        lblAcctransfer_2_2.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAcctransfer_2_2.setBounds(10, 432, 210, 49);
        contentPane.add(lblAcctransfer_2_2);

        JLabel lblAcctransfer_2_3 = new JLabel("transferAmount");
        lblAcctransfer_2_3.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAcctransfer_2_3.setBounds(10, 492, 193, 49);
        contentPane.add(lblAcctransfer_2_3);

        accDep = new JTextField();
        accDep.setBounds(240, 120, 260, 39);
        contentPane.add(accDep);
        accDep.setColumns(10);

        accWith = new JTextField();
        accWith.setColumns(10);
        accWith.setBounds(240, 180, 260, 39);
        contentPane.add(accWith);

        acc1 = new JTextField();
        acc1.setColumns(10);
        acc1.setBounds(240, 247, 260, 39);
        contentPane.add(acc1);

        acc2 = new JTextField();
        acc2.setColumns(10);
        acc2.setBounds(240, 307, 260, 39);
        contentPane.add(acc2);

        depInp = new JTextField();
        depInp.setColumns(10);
        depInp.setBounds(240, 367, 260, 39);
        contentPane.add(depInp);

        withInp = new JTextField();
        withInp.setColumns(10);
        withInp.setBounds(240, 432, 260, 39);
        contentPane.add(withInp);

        transAmnt = new JTextField();
        transAmnt.setColumns(10);
        transAmnt.setBounds(240, 504, 260, 39);
        contentPane.add(transAmnt);

        details = new JTextArea();
        details.setFont(new Font("Arial", Font.PLAIN, 14));
        details.setBounds(585, 201, 507, 151);
        details.setEditable(false);
        contentPane.add(details);
        details.setColumns(10);
        details.setForeground(new Color(0, 0, 128));
        details.setBackground(new Color(255, 255, 255));

        JLabel lblNewLabel_1 = new JLabel("Details");
        lblNewLabel_1.setForeground(new Color(255, 0, 0));
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 24));
        lblNewLabel_1.setBounds(798, 160, 72, 39);
        contentPane.add(lblNewLabel_1);
    }

    // Method to setup button actions
    
    private void setupButtonActions() {
        JButton depBtn = new JButton("Deposit");
        depBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performDeposit();
            }
        });
        depBtn.setForeground(Color.BLUE);
        depBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
        depBtn.setBounds(27, 578, 193, 77);
        contentPane.add(depBtn);

        JButton withdrawBtn = new JButton("Withdraw");
        withdrawBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performWithdraw();
            }
        });
        withdrawBtn.setForeground(Color.BLUE);
        withdrawBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
        withdrawBtn.setBounds(240, 578, 193, 77);
        contentPane.add(withdrawBtn);

        JButton transferBtn = new JButton("Transfer");
        transferBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performTransfer();
            }
        });
        transferBtn.setForeground(Color.BLUE);
        transferBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
        transferBtn.setBounds(459, 578, 193, 77);
        contentPane.add(transferBtn);
        
//Show Button
        
        JButton showAllBtn = new JButton("Show All");
        showAllBtn.addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
                displayAccountDetails();
            }
        });
        showAllBtn.setForeground(Color.BLUE);
        showAllBtn.setFont(new Font("Tahoma", Font.PLAIN, 18));
        showAllBtn.setBounds(695, 578, 204, 77);
        contentPane.add(showAllBtn);

        JLabel lblAccdeposit = new JLabel("accDeposit");
        lblAccdeposit.setFont(new Font("Tahoma", Font.PLAIN, 27));
        lblAccdeposit.setBounds(10, 127, 193, 49);
        contentPane.add(lblAccdeposit);
    }

    // Method to perform deposit action
    private void performDeposit() {
        try {
            String account = accDep.getText();
            String amountStr = depInp.getText();

            if (account.isEmpty() || amountStr.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both account number and amount.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double amount = Double.parseDouble(amountStr);
            updateAccountBalance(account, amount, true, null, null);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number for the amount.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    

    // Method to perform withdraw action
    
    private void performWithdraw() {
        try {
            String account = accWith.getText();
            String amountStr = withInp.getText();

            if (account.isEmpty() || amountStr.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both account number and amount.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double amount = Double.parseDouble(amountStr);
            updateAccountBalance(account, amount, false, null, null);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number for the amount.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    
    // Method to perform transfer action
    
    private void performTransfer() {
        try {
            String account1 = acc1.getText().trim();
            String account2 = acc2.getText().trim();
            String amountStr = transAmnt.getText().trim();

            if (account1.isEmpty() || account2.isEmpty() || amountStr.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both account numbers and the amount.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                JOptionPane.showMessageDialog(null, "Amount should be greater than zero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Perform the transfer
            updateAccountBalance(account1, amount, false, account2, amountStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number for the amount.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    
    // Method to update account balance and the CSV file

    private void updateAccountBalance(String accountNumber, double amount, boolean isDeposit, String toAccountNumber, String transferAmountStr) {
        boolean updated = false;

        Account sourceAccount = null;
        Account destinationAccount = null;

        // Find the source and destination accounts
        for (Account acc : accounts) {
            if (acc.getAccountNum() == Integer.parseInt(accountNumber)) {
                sourceAccount = acc;
            }
            if (toAccountNumber != null && !toAccountNumber.isEmpty() && acc.getAccountNum() == Integer.parseInt(toAccountNumber)) {
                destinationAccount = acc;
            }
        }

        if (sourceAccount != null) {
            if (isDeposit) {
                sourceAccount.deposit((int) amount);
                updated = true;
            } else {
                if (sourceAccount.getBalance() >= amount) {
                    sourceAccount.withdraw((int) amount);
                    updated = true;

                    // If a transfer is intended (i.e., toAccountNumber is provided), update destination account
                    if (toAccountNumber != null) {
                        if (destinationAccount != null) {
                            int transferAmount = (transferAmountStr != null && !transferAmountStr.isEmpty()) 
                                ? Integer.parseInt(transferAmountStr) 
                                : (int) amount;

                            destinationAccount.deposit(transferAmount);
                        } else {
                            JOptionPane.showMessageDialog(null, "Destination account not found.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Insufficient funds.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Source account not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (updated) {
            writeToCsv();
            JOptionPane.showMessageDialog(null, "Operation successful.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    private void writeToCsv() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("resources/Accounts.csv"))) {
            for (Account acc : accounts) {
                pw.println(acc.getFirstName() + "," + acc.getLastName() + "," + acc.getAccountNum() + "," + acc.getBalance());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to CSV file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    

    // Method to display account details in the JTextArea
    
    private void displayAccountDetails() {
        StringBuilder sb = new StringBuilder();
        for (Account acc : accounts) {
            sb.append("Account Number: ").append(acc.getAccountNum())
              .append(", Name: ").append(acc.getFirstName()).append(" ").append(acc.getLastName())
              .append(", Balance: ").append(acc.getBalance()).append("\n");
        }
        details.setText(sb.toString());
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LinkedList<Account> accounts = new LinkedList<>();
                    GUI frame = new GUI(accounts);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}